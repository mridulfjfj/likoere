
import React, { useState, useCallback, useMemo } from 'react';
import { AppState, Screen, Restaurant, Dish, CartItem } from './types';
import { DUMMY_RESTAURANTS, DUMMY_DISHES } from './constants';
import Layout from './components/Layout';
import HomeScreen from './screens/HomeScreen';
import RestaurantDetailsScreen from './screens/RestaurantDetailsScreen';
import CartScreen from './screens/CartScreen';
import TrackingScreen from './screens/TrackingScreen';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    currentScreen: 'HOME',
    selectedRestaurantId: null,
    cart: [],
  });

  const setScreen = useCallback((screen: Screen) => {
    setState(prev => ({ ...prev, currentScreen: screen }));
  }, []);

  const selectRestaurant = useCallback((id: string) => {
    setState(prev => ({ 
      ...prev, 
      selectedRestaurantId: id, 
      currentScreen: 'DETAILS' 
    }));
  }, []);

  const addToCart = useCallback((dish: Dish) => {
    setState(prev => {
      const existing = prev.cart.find(item => item.id === dish.id);
      if (existing) {
        return {
          ...prev,
          cart: prev.cart.map(item => item.id === dish.id ? { ...item, quantity: item.quantity + 1 } : item)
        };
      }
      return { ...prev, cart: [...prev.cart, { ...dish, quantity: 1 }] };
    });
  }, []);

  const removeFromCart = useCallback((dishId: string) => {
    setState(prev => {
      const existing = prev.cart.find(item => item.id === dishId);
      if (existing && existing.quantity > 1) {
        return {
          ...prev,
          cart: prev.cart.map(item => item.id === dishId ? { ...item, quantity: item.quantity - 1 } : item)
        };
      }
      return { ...prev, cart: prev.cart.filter(item => item.id !== dishId) };
    });
  }, []);

  const cartTotal = useMemo(() => {
    return state.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  }, [state.cart]);

  const renderScreen = () => {
    switch (state.currentScreen) {
      case 'HOME':
        return <HomeScreen onSelectRestaurant={selectRestaurant} />;
      case 'DETAILS':
        const res = DUMMY_RESTAURANTS.find(r => r.id === state.selectedRestaurantId);
        const dishes = state.selectedRestaurantId ? DUMMY_DISHES[state.selectedRestaurantId] || [] : [];
        return (
          <RestaurantDetailsScreen 
            restaurant={res!} 
            dishes={dishes} 
            onBack={() => setScreen('HOME')}
            onAddToCart={addToCart}
            onRemoveFromCart={removeFromCart}
            cart={state.cart}
          />
        );
      case 'CART':
        return (
          <CartScreen 
            cart={state.cart} 
            onCheckout={() => setScreen('TRACKING')} 
            onBack={() => setScreen('HOME')}
            onUpdateQuantity={(id, delta) => {
              if (delta > 0) addToCart(state.cart.find(i => i.id === id)!);
              else removeFromCart(id);
            }}
          />
        );
      case 'TRACKING':
        return <TrackingScreen onBack={() => setScreen('HOME')} />;
      default:
        return <HomeScreen onSelectRestaurant={selectRestaurant} />;
    }
  };

  return (
    <Layout 
      activeScreen={state.currentScreen} 
      setScreen={setScreen}
      cartCount={state.cart.reduce((a, b) => a + b.quantity, 0)}
    >
      {renderScreen()}
    </Layout>
  );
};

export default App;
