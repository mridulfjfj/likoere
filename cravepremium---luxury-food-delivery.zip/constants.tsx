
import { Restaurant, Dish } from './types';

export const THEME_COLORS = {
  primary: '#D32F2F', // Cranberry Red
  white: '#FFFFFF',
  charcoal: '#333333',
  lightGray: '#F8FAFC',
  accent: '#FFD700', // Gold for ratings
};

export const CUISINES = [
  { id: '1', name: 'Italian', icon: '🍝' },
  { id: '2', name: 'Japanese', icon: '🍣' },
  { id: '3', name: 'Indian', icon: '🍛' },
  { id: '4', name: 'Burgers', icon: '🍔' },
  { id: '5', name: 'Healthy', icon: '🥗' },
  { id: '6', name: 'Desserts', icon: '🍰' },
];

export const DUMMY_RESTAURANTS: Restaurant[] = [
  {
    id: 'r1',
    name: 'The Gourmet Kitchen',
    cuisine: ['Italian', 'Continental'],
    rating: 4.8,
    deliveryTime: '25-30 min',
    priceLevel: 3,
    image: 'https://picsum.photos/seed/res1/800/500',
    isVeg: false,
    featured: true,
  },
  {
    id: 'r2',
    name: 'Sushi Zen',
    cuisine: ['Japanese', 'Seafood'],
    rating: 4.9,
    deliveryTime: '35-40 min',
    priceLevel: 4,
    image: 'https://picsum.photos/seed/res2/800/500',
    isVeg: false,
    featured: true,
  },
  {
    id: 'r3',
    name: 'Green Bowl',
    cuisine: ['Healthy', 'Salads'],
    rating: 4.5,
    deliveryTime: '20-25 min',
    priceLevel: 2,
    image: 'https://picsum.photos/seed/res3/800/500',
    isVeg: true,
  },
  {
    id: 'r4',
    name: 'Burger Smith',
    cuisine: ['American', 'Fast Food'],
    rating: 4.3,
    deliveryTime: '15-20 min',
    priceLevel: 2,
    image: 'https://picsum.photos/seed/res4/800/500',
    isVeg: false,
  },
];

export const DUMMY_DISHES: Record<string, Dish[]> = {
  'r1': [
    { id: 'd1', name: 'Truffle Mushroom Risotto', price: 24, category: 'Main Course', description: 'Creamy Arborio rice with black truffle oil and wild mushrooms.', image: 'https://picsum.photos/seed/d1/400/400', isVeg: true, rating: 4.9 },
    { id: 'd2', name: 'Wood-fired Pepperoni', price: 18, category: 'Pizza', description: 'Authentic sourdough crust with spicy pepperoni and fresh mozzarella.', image: 'https://picsum.photos/seed/d2/400/400', isVeg: false, rating: 4.7 },
    { id: 'd3', name: 'Tiramisu', price: 12, category: 'Dessert', description: 'Classic Italian coffee-flavoured dessert.', image: 'https://picsum.photos/seed/d3/400/400', isVeg: true },
  ],
  'r2': [
    { id: 'd4', name: 'Omakase Set', price: 65, category: 'Sushi', description: 'Chef\'s selection of 12 premium nigiri pieces.', image: 'https://picsum.photos/seed/d4/400/400', isVeg: false, rating: 5.0 },
    { id: 'd5', name: 'Miso Ramen', price: 22, category: 'Noodles', description: 'Rich pork broth with marinated egg and bamboo shoots.', image: 'https://picsum.photos/seed/d5/400/400', isVeg: false, rating: 4.8 },
  ],
};
