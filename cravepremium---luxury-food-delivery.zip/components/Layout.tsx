
import React from 'react';
import { Home, Search, ShoppingBag, MapPin, User } from 'lucide-react';
import { Screen } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeScreen: Screen;
  setScreen: (screen: Screen) => void;
  cartCount: number;
}

const Layout: React.FC<LayoutProps> = ({ children, activeScreen, setScreen, cartCount }) => {
  return (
    <div className="flex flex-col min-h-screen max-w-md mx-auto bg-white relative">
      <main className="flex-1 pb-24">
        {children}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-100 px-6 py-4 flex justify-between items-center z-50">
        <NavButton 
          icon={<Home size={24} />} 
          label="Home" 
          active={activeScreen === 'HOME'} 
          onClick={() => setScreen('HOME')} 
        />
        <NavButton 
          icon={<Search size={24} />} 
          label="Search" 
          active={activeScreen === 'SEARCH'} 
          onClick={() => setScreen('SEARCH')} 
        />
        <div className="relative">
          <NavButton 
            icon={<ShoppingBag size={24} />} 
            label="Cart" 
            active={activeScreen === 'CART'} 
            onClick={() => setScreen('CART')} 
          />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-[#D32F2F] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
              {cartCount}
            </span>
          )}
        </div>
        <NavButton 
          icon={<MapPin size={24} />} 
          label="Track" 
          active={activeScreen === 'TRACKING'} 
          onClick={() => setScreen('TRACKING')} 
        />
        <NavButton 
          icon={<User size={24} />} 
          label="Profile" 
          active={false} 
          onClick={() => {}} 
        />
      </nav>
    </div>
  );
};

interface NavButtonProps {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick: () => void;
}

const NavButton: React.FC<NavButtonProps> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center gap-1 transition-all duration-300 ${active ? 'text-[#D32F2F]' : 'text-gray-400'}`}
  >
    {icon}
    <span className="text-[10px] font-medium">{label}</span>
  </button>
);

export default Layout;
