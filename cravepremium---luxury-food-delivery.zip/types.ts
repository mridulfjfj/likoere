
export interface Restaurant {
  id: string;
  name: string;
  cuisine: string[];
  rating: number;
  deliveryTime: string;
  priceLevel: number;
  image: string;
  isVeg: boolean;
  featured?: boolean;
}

export interface Dish {
  id: string;
  name: string;
  price: number;
  category: string;
  description: string;
  image: string;
  isVeg: boolean;
  rating?: number;
}

export interface CartItem extends Dish {
  quantity: number;
}

export type Screen = 'HOME' | 'DETAILS' | 'SEARCH' | 'CART' | 'TRACKING';

export interface AppState {
  currentScreen: Screen;
  selectedRestaurantId: string | null;
  cart: CartItem[];
}
