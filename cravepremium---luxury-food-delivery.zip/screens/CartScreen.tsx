
import React from 'react';
import { ArrowLeft, Trash2, Plus, Minus, CreditCard, ChevronRight } from 'lucide-react';
import { CartItem } from '../types';

interface CartScreenProps {
  cart: CartItem[];
  onBack: () => void;
  onCheckout: () => void;
  onUpdateQuantity: (id: string, delta: number) => void;
}

const CartScreen: React.FC<CartScreenProps> = ({ cart, onBack, onCheckout, onUpdateQuantity }) => {
  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const deliveryFee = subtotal > 0 ? 5.00 : 0;
  const tax = subtotal * 0.08;
  const total = subtotal + deliveryFee + tax;

  if (cart.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] px-8 text-center space-y-6">
        <div className="w-48 h-48 bg-gray-50 rounded-full flex items-center justify-center">
          <span className="text-6xl">🛒</span>
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-black">Your cart is empty</h2>
          <p className="text-gray-400 font-medium">Looks like you haven't added anything to your cart yet.</p>
        </div>
        <button 
          onClick={onBack}
          className="bg-[#D32F2F] text-white px-10 py-4 rounded-2xl font-bold shadow-xl active:scale-95 transition-transform"
        >
          Explore Restaurants
        </button>
      </div>
    );
  }

  return (
    <div className="animate-in slide-in-from-right-8 duration-500 p-6 flex flex-col gap-8 pb-32">
      <div className="flex items-center gap-4">
        <button onClick={onBack} className="p-2 -ml-2 text-gray-400 hover:text-black transition-colors">
          <ArrowLeft size={24} />
        </button>
        <h1 className="text-2xl font-black">Checkout</h1>
      </div>

      {/* Cart Items */}
      <div className="space-y-6">
        {cart.map((item) => (
          <div key={item.id} className="flex gap-4 items-center">
            <div className="w-16 h-16 rounded-xl overflow-hidden bg-gray-100">
              <img src={item.image} className="w-full h-full object-cover" alt={item.name} />
            </div>
            <div className="flex-1 space-y-1">
              <h4 className="font-bold text-sm">{item.name}</h4>
              <p className="text-xs text-gray-400">${item.price}</p>
            </div>
            <div className="flex items-center gap-3 bg-gray-100 rounded-lg p-1 px-2">
              <button onClick={() => onUpdateQuantity(item.id, -1)} className="p-1 hover:text-[#D32F2F]"><Minus size={14} /></button>
              <span className="text-sm font-black w-4 text-center">{item.quantity}</span>
              <button onClick={() => onUpdateQuantity(item.id, 1)} className="p-1 hover:text-[#D32F2F]"><Plus size={14} /></button>
            </div>
          </div>
        ))}
      </div>

      <hr className="border-gray-50" />

      {/* Address & Payment Placeholder */}
      <div className="space-y-4">
        <div className="bg-white border border-gray-100 p-4 rounded-2xl flex items-center justify-between shadow-sm cursor-pointer hover:bg-gray-50 transition-colors">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-red-50 text-[#D32F2F] rounded-lg">
              <CreditCard size={20} />
            </div>
            <div className="flex flex-col">
              <span className="text-xs text-gray-400 font-bold uppercase tracking-widest">Payment Method</span>
              <span className="text-sm font-bold">Apple Pay •••• 4242</span>
            </div>
          </div>
          <ChevronRight size={18} className="text-gray-300" />
        </div>
      </div>

      {/* Bill Details */}
      <div className="bg-gray-50/50 p-6 rounded-3xl space-y-4 border border-gray-100">
        <div className="flex justify-between items-center text-sm font-medium">
          <span className="text-gray-400">Subtotal</span>
          <span>${subtotal.toFixed(2)}</span>
        </div>
        <div className="flex justify-between items-center text-sm font-medium">
          <span className="text-gray-400">Delivery Fee</span>
          <span className="text-green-500 font-bold">Free</span>
        </div>
        <div className="flex justify-between items-center text-sm font-medium">
          <span className="text-gray-400">Service Tax (8%)</span>
          <span>${tax.toFixed(2)}</span>
        </div>
        <hr className="border-gray-200" />
        <div className="flex justify-between items-center">
          <span className="text-lg font-black">Total</span>
          <span className="text-2xl font-black text-[#D32F2F]">${total.toFixed(2)}</span>
        </div>
      </div>

      {/* Floating Action Button */}
      <div className="fixed bottom-24 left-1/2 -translate-x-1/2 w-full max-w-md px-6">
        <button 
          onClick={onCheckout}
          className="w-full bg-[#D32F2F] text-white py-4 rounded-2xl font-black shadow-2xl shadow-red-200 flex items-center justify-center gap-3 active:scale-95 transition-all group"
        >
          Place Order
          <div className="w-1.5 h-1.5 rounded-full bg-white group-hover:scale-150 transition-transform"></div>
          <ChevronRight size={20} />
        </button>
      </div>
    </div>
  );
};

export default CartScreen;
