
import React, { useState } from 'react';
import { ArrowLeft, Share2, Heart, Clock, Star, Minus, Plus } from 'lucide-react';
import { Restaurant, Dish, CartItem } from '../types';

interface RestaurantDetailsScreenProps {
  restaurant: Restaurant;
  dishes: Dish[];
  onBack: () => void;
  onAddToCart: (dish: Dish) => void;
  onRemoveFromCart: (dishId: string) => void;
  cart: CartItem[];
}

const RestaurantDetailsScreen: React.FC<RestaurantDetailsScreenProps> = ({ 
  restaurant, dishes, onBack, onAddToCart, onRemoveFromCart, cart 
}) => {
  const [activeTab, setActiveTab] = useState('Recommended');
  const categories = ['Recommended', ...new Set(dishes.map(d => d.category))];

  const getQuantity = (id: string) => cart.find(i => i.id === id)?.quantity || 0;

  return (
    <div className="animate-in fade-in duration-500 pb-12">
      {/* Hero Header */}
      <div className="relative h-64">
        <img src={restaurant.image} className="w-full h-full object-cover" alt={restaurant.name} />
        <div className="absolute top-0 left-0 right-0 p-6 flex justify-between items-center z-10">
          <button onClick={onBack} className="w-10 h-10 bg-white/90 backdrop-blur rounded-full flex items-center justify-center shadow-lg">
            <ArrowLeft size={20} />
          </button>
          <div className="flex gap-3">
            <button className="w-10 h-10 bg-white/90 backdrop-blur rounded-full flex items-center justify-center shadow-lg">
              <Share2 size={18} />
            </button>
            <button className="w-10 h-10 bg-white/90 backdrop-blur rounded-full flex items-center justify-center shadow-lg">
              <Heart size={18} className="text-[#D32F2F]" />
            </button>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-black/60 to-transparent"></div>
      </div>

      {/* Info Card */}
      <div className="px-6 -mt-12 relative z-20">
        <div className="bg-white p-6 rounded-3xl shadow-xl border border-gray-100 flex flex-col gap-4">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <h1 className="text-2xl font-black text-[#333333] leading-tight">{restaurant.name}</h1>
              <p className="text-gray-400 text-sm font-medium">{restaurant.cuisine.join(' • ')}</p>
            </div>
            <div className="flex flex-col items-end">
              <div className="bg-[#D32F2F] text-white px-2 py-1 rounded-lg flex items-center gap-1 font-bold text-sm">
                <Star size={14} fill="currentColor" />
                {restaurant.rating}
              </div>
              <span className="text-[10px] text-gray-400 mt-1">500+ Reviews</span>
            </div>
          </div>

          <hr className="border-gray-50" />

          <div className="flex justify-around items-center">
            <div className="flex flex-col items-center gap-1">
              <Clock size={16} className="text-gray-400" />
              <span className="text-xs font-bold">{restaurant.deliveryTime}</span>
            </div>
            <div className="w-px h-8 bg-gray-100"></div>
            <div className="flex flex-col items-center gap-1">
              <span className="text-sm font-black text-[#D32F2F]">{'$'.repeat(restaurant.priceLevel)}</span>
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wide">Premium</span>
            </div>
            <div className="w-px h-8 bg-gray-100"></div>
            <div className="flex flex-col items-center gap-1">
              <div className="w-4 h-4 rounded-full border border-green-500 p-0.5 flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
              </div>
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wide">Pure Veg</span>
            </div>
          </div>
        </div>
      </div>

      {/* Menu Categories */}
      <div className="mt-8 px-6">
        <div className="flex gap-6 overflow-x-auto pb-4 no-scrollbar border-b border-gray-100">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveTab(cat)}
              className={`text-sm font-bold whitespace-nowrap transition-all relative py-1 ${activeTab === cat ? 'text-[#D32F2F]' : 'text-gray-400'}`}
            >
              {cat}
              {activeTab === cat && <div className="absolute -bottom-[1px] left-0 right-0 h-[3px] bg-[#D32F2F] rounded-full"></div>}
            </button>
          ))}
        </div>
      </div>

      {/* Dishes List */}
      <div className="px-6 mt-6 space-y-8">
        {dishes.filter(d => activeTab === 'Recommended' || d.category === activeTab).map((dish) => (
          <div key={dish.id} className="flex justify-between gap-6 pb-6 border-b border-gray-50 last:border-none group">
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-2">
                <div className={`w-3.5 h-3.5 border ${dish.isVeg ? 'border-green-500' : 'border-red-500'} p-0.5 flex items-center justify-center`}>
                  <div className={`w-1.5 h-1.5 rounded-full ${dish.isVeg ? 'bg-green-500' : 'bg-red-500'}`}></div>
                </div>
                {dish.rating && (
                  <div className="flex items-center gap-1 text-[10px] text-[#D32F2F] font-bold bg-[#D32F2F]/5 px-2 py-0.5 rounded">
                    ★ {dish.rating}
                  </div>
                )}
              </div>
              <h3 className="font-bold text-lg text-[#333333] group-hover:text-[#D32F2F] transition-colors">{dish.name}</h3>
              <p className="text-gray-400 text-xs line-clamp-2 font-medium">{dish.description}</p>
              <div className="text-lg font-black text-[#333333]">${dish.price}</div>
            </div>
            <div className="relative">
              <div className="w-32 h-32 rounded-2xl overflow-hidden shadow-md">
                <img src={dish.image} className="w-full h-full object-cover" alt={dish.name} />
              </div>
              <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-[80%]">
                {getQuantity(dish.id) === 0 ? (
                  <button 
                    onClick={() => onAddToCart(dish)}
                    className="w-full bg-white border border-[#D32F2F] text-[#D32F2F] py-2 rounded-xl text-xs font-black shadow-lg hover:bg-[#D32F2F] hover:text-white transition-all active:scale-95"
                  >
                    ADD
                  </button>
                ) : (
                  <div className="w-full bg-[#D32F2F] text-white py-2 rounded-xl flex items-center justify-between px-3 shadow-lg">
                    <button onClick={() => onRemoveFromCart(dish.id)}><Minus size={14} /></button>
                    <span className="text-xs font-black">{getQuantity(dish.id)}</span>
                    <button onClick={() => onAddToCart(dish)}><Plus size={14} /></button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RestaurantDetailsScreen;
