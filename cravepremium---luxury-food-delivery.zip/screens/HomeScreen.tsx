
import React, { useState, useEffect } from 'react';
import { Search as SearchIcon, MapPin, ChevronRight, Sparkles } from 'lucide-react';
import { CUISINES, DUMMY_RESTAURANTS } from '../constants';
import { getSmartRecommendations } from '../services/geminiService';

interface HomeScreenProps {
  onSelectRestaurant: (id: string) => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ onSelectRestaurant }) => {
  const [craving, setCraving] = useState('');
  const [aiRecs, setAiRecs] = useState<{ dish: string, reason: string }[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleAISearch = async () => {
    if (!craving) return;
    setIsSearching(true);
    const result = await getSmartRecommendations(craving);
    if (result) setAiRecs(result);
    setIsSearching(false);
  };

  return (
    <div className="flex flex-col px-6 pt-8 gap-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Header */}
      <div className="flex justify-between items-start">
        <div className="flex flex-col">
          <span className="text-gray-400 text-sm font-medium">Deliver to</span>
          <div className="flex items-center gap-1 text-[#333333] font-bold text-lg">
            <MapPin size={18} className="text-[#D32F2F]" />
            <span>Manhattan, NY</span>
          </div>
        </div>
        <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden border-2 border-white shadow-sm">
          <img src="https://picsum.photos/100/100" alt="Profile" />
        </div>
      </div>

      {/* AI Search Bar */}
      <div className="relative">
        <div className="flex items-center bg-gray-100 rounded-2xl px-4 py-3 shadow-inner group transition-all focus-within:ring-2 focus-within:ring-[#D32F2F]/20">
          <SearchIcon size={20} className="text-gray-400 mr-3" />
          <input 
            type="text" 
            placeholder="Craving something specific?" 
            className="bg-transparent border-none outline-none flex-1 text-sm font-medium"
            value={craving}
            onChange={(e) => setCraving(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleAISearch()}
          />
          <button 
            onClick={handleAISearch}
            className="p-2 bg-[#D32F2F] rounded-xl text-white shadow-lg hover:scale-105 active:scale-95 transition-transform"
          >
            <Sparkles size={16} />
          </button>
        </div>
      </div>

      {/* AI Recommendations */}
      {aiRecs.length > 0 && (
        <div className="bg-[#D32F2F]/5 p-4 rounded-2xl border border-[#D32F2F]/10 animate-in zoom-in-95 duration-300">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles size={16} className="text-[#D32F2F]" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#D32F2F]">Chef's AI Suggestions</h3>
          </div>
          <div className="space-y-3">
            {aiRecs.map((rec, i) => (
              <div key={i} className="flex flex-col">
                <span className="text-sm font-bold text-[#333333]">{rec.dish}</span>
                <span className="text-[11px] text-gray-500 italic">"{rec.reason}"</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Cuisines Horizontal Scroll */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold">Cuisines</h2>
          <button className="text-[#D32F2F] text-sm font-semibold flex items-center">
            View All <ChevronRight size={16} />
          </button>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-2 -mx-6 px-6 no-scrollbar">
          {CUISINES.map((c) => (
            <div key={c.id} className="flex flex-col items-center gap-2 min-w-[70px]">
              <div className="w-16 h-16 rounded-2xl bg-white shadow-sm border border-gray-50 flex items-center justify-center text-2xl hover:bg-gray-50 transition-colors cursor-pointer">
                {c.icon}
              </div>
              <span className="text-[11px] font-bold text-gray-500">{c.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Featured Tier */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold">Recommended for You</h2>
        <div className="flex gap-4 overflow-x-auto -mx-6 px-6 pb-4 no-scrollbar">
          {DUMMY_RESTAURANTS.filter(r => r.featured).map((r) => (
            <div 
              key={r.id} 
              className="min-w-[280px] bg-white rounded-3xl overflow-hidden shadow-lg border border-gray-100 group cursor-pointer"
              onClick={() => onSelectRestaurant(r.id)}
            >
              <div className="relative h-40 overflow-hidden">
                <img 
                  src={r.image} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  alt={r.name}
                />
                <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-[#D32F2F]">
                  ★ {r.rating}
                </div>
                {r.isVeg && (
                  <div className="absolute bottom-3 left-3 bg-green-500 text-white p-1 rounded-md">
                    <div className="w-2 h-2 rounded-full bg-white"></div>
                  </div>
                )}
              </div>
              <div className="p-4 space-y-1">
                <h3 className="font-bold text-lg">{r.name}</h3>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-gray-500 font-medium">{r.cuisine.join(', ')}</span>
                  <span className="text-gray-400">{r.deliveryTime}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Popular Section */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold">Top Rated Near You</h2>
        <div className="space-y-4">
          {DUMMY_RESTAURANTS.map((r) => (
            <div 
              key={r.id}
              onClick={() => onSelectRestaurant(r.id)}
              className="flex gap-4 bg-white p-3 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-all cursor-pointer"
            >
              <div className="w-24 h-24 rounded-xl overflow-hidden flex-shrink-0">
                <img src={r.image} className="w-full h-full object-cover" alt={r.name} />
              </div>
              <div className="flex flex-col justify-center flex-1 gap-1">
                <div className="flex justify-between">
                  <h3 className="font-bold">{r.name}</h3>
                  <span className="text-xs font-bold">★ {r.rating}</span>
                </div>
                <p className="text-xs text-gray-400">{r.cuisine.join(' • ')}</p>
                <div className="flex items-center gap-2 mt-1">
                  <div className="bg-gray-100 px-2 py-0.5 rounded text-[10px] font-bold text-gray-500">{r.deliveryTime}</div>
                  <div className="text-[10px] font-bold text-gray-300">|</div>
                  <div className="text-[10px] font-bold text-gray-500">{'$'.repeat(r.priceLevel)}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomeScreen;
