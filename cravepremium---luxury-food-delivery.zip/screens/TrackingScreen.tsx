
import React from 'react';
import { ArrowLeft, Phone, MessageSquare, CheckCircle2 } from 'lucide-react';

interface TrackingScreenProps {
  onBack: () => void;
}

const TrackingScreen: React.FC<TrackingScreenProps> = ({ onBack }) => {
  return (
    <div className="flex flex-col h-full bg-[#D32F2F] animate-in fade-in duration-500">
      <div className="p-6 flex items-center justify-between text-white">
        <button onClick={onBack} className="p-2 bg-white/20 rounded-full backdrop-blur">
          <ArrowLeft size={20} />
        </button>
        <div className="flex flex-col items-center">
          <h2 className="text-sm font-black uppercase tracking-widest">Order Tracking</h2>
          <span className="text-[10px] opacity-70">ETA: 22 MIN</span>
        </div>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 relative bg-gray-100 rounded-t-[40px] overflow-hidden">
        {/* Placeholder Map */}
        <div className="absolute inset-0 bg-blue-50">
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'radial-gradient(circle, #000 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
          {/* Mock Map Route */}
          <svg className="absolute inset-0 w-full h-full">
            <path d="M 50 400 L 150 300 L 250 350 L 350 200" fill="none" stroke="#D32F2F" strokeWidth="4" strokeDasharray="8 4" />
          </svg>
          {/* Driver Pin */}
          <div className="absolute top-[190px] left-[340px] -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
            <div className="bg-[#D32F2F] p-2 rounded-full shadow-lg border-2 border-white animate-bounce">
              <span className="text-xl">🛵</span>
            </div>
          </div>
          {/* Home Pin */}
          <div className="absolute top-[390px] left-[40px] flex flex-col items-center">
            <div className="bg-white p-2 rounded-full shadow-lg border-2 border-[#D32F2F]">
              <span className="text-xl">📍</span>
            </div>
          </div>
        </div>

        {/* Status Sheet */}
        <div className="absolute bottom-0 left-0 right-0 bg-white p-8 rounded-t-[40px] shadow-2xl flex flex-col gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gray-100 overflow-hidden">
              <img src="https://picsum.photos/seed/driver/200/200" alt="Driver" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-black text-[#333333]">Alex Thompson</h3>
              <p className="text-xs text-gray-400 font-bold uppercase tracking-wider">Your Courier Partner</p>
            </div>
            <div className="flex gap-2">
              <button className="p-3 bg-gray-50 text-[#333333] rounded-2xl shadow-sm"><Phone size={20} /></button>
              <button className="p-3 bg-gray-50 text-[#D32F2F] rounded-2xl shadow-sm"><MessageSquare size={20} /></button>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex gap-4 items-start relative">
              <div className="w-1 h-full absolute left-3.5 top-8 bg-gray-100"></div>
              <div className="z-10 bg-green-500 text-white p-1 rounded-full"><CheckCircle2 size={18} /></div>
              <div className="flex flex-col">
                <span className="text-sm font-black">Order Received</span>
                <span className="text-xs text-gray-400">The restaurant is preparing your food</span>
              </div>
            </div>
            <div className="flex gap-4 items-start">
              <div className="z-10 bg-gray-100 text-gray-300 p-1 rounded-full"><div className="w-[18px] h-[18px]"></div></div>
              <div className="flex flex-col opacity-50">
                <span className="text-sm font-black">Out for Delivery</span>
                <span className="text-xs text-gray-400">Alex is headed to your location</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrackingScreen;
